<?php 
    require_once 'securimage.php';?>

<!DOCTYPE html>
<html>
<head>
	<title>Captcha</title>
</head>
<body>

    <form method="post" action=""> 
    <div>
        <?php echo Securimage::getCaptchaHtml() ?>


		<?php   $image = new Securimage();
  	  if ($image->check($_POST['captcha_code']) == true) {
      echo "Correct!";
   	 } else {
      echo "Sorry, wrong code.";
   			 } ?>
	    </div>
    </form>
    
   
</body>
</html>