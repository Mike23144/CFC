
<!--PHP MAILER CODE START HERE-->
<?php

require_once './config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require 'Composer\vendor\autoload.php';

if (isset($_POST["sub"])) {
  require_once "phpmailer/class.phpmailer.php";

  $name = trim($_POST["name"]);
  $username = trim($_POST["username"]);
  $email = trim($_POST["email"]);
  $password = trim($_POST["password1"]);

  $sql = "SELECT COUNT(*) AS count from tbl_users where email = :email_id";

   try {
    $stmt = $DB->prepare($sql);
    $stmt->bindValue(":email_id", $email);
    $stmt->execute();
    $result = $stmt->fetchAll();

    if ($result[0]["count"] > 0) {
      $msg = "Email already exist";
      $msgType = "warning";
    } else {
      $sql = "INSERT INTO `tbl_users`(`fullname`, `name` ,`email`, `pass`) VALUES " . "( :name, :username, :email, :password)";
      $stmt = $DB->prepare($sql);
      $stmt->bindValue(":name", $name);
      $stmt->bindValue(":username", $username);
      $stmt->bindValue(":email", $email);
      $stmt->bindValue(":password", md5($password));
   
    
      $stmt->execute();
      $result = $stmt->rowCount();


      if ($result > 0) {
       
        $lastID = $DB->lastInsertId();

        $message = '<html><head>
                <title>Email Verification</title>
                </head>
                <body>';
        $message .= '<h1>Hi ' . $name . '!</h1>';
        $message .=  '<p>Your account has been activate.<p/>';
        
        $message .= '<p><a href="'.SITE_URL.'activate.php?id=' . base64_encode($lastID) . '" style="
        padding:5px 10px; background:orange; color:white; fontsize:16px;">Proceed</a></p>';
        $message .= "</body></html>";
        

          // php mailer code starts
        $mail = new PHPMailer(true);
        $mail->SMTPDebug = 0;
                            $mail->isSMTP();
                            $mail->Host = 'smtp.gmail.com;smtp.mail.yahoo.com';
                            $mail->SMTPAuth = true;
                            $mail->Username = 'michaelGcweb@gmail.com';
                            $mail->Password = '2309102554497';
                            $mail->SMTPSecure = 'tls';
                            $mail->Port = 587;
                            $mail->SetFrom('michaelGcweb@gmail.com', 'Michael');
        $mail->AddAddress($email);
        $mail->isHTML(true);   
        $mail->Subject = trim("metromta.pcriot.com");
  
                try {
          
        $mail->MsgHTML($message);
             $mail->SMTPOptions = array(
                                'ssl' => array(
                                    'verify_peer' => false,
                                    'verify_peer_name' => false,
                                    'allow_self_signed' => true
                                )
                            );

          $mail->send();
        
          $msg = "An email has been sent for verification. Please check your email for activation link..";
          $msgType = "success";
        } catch (Exception $ex) {
          $msg = $ex->getMessage();
          $msgType = "warning";
        }
      } else {
        $msg = "Failed to create User";
        $msgType = "warning";
      }
    }
  } catch (Exception $ex) {
    echo $ex->getMessage();
  }
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Online Assessment test : Home</title>
</head>


</head>

<body>

<?php include('Attribute/header.php') ?>


<?php if ($msg <> "") { ?>
  <div class="alert  alert-dismissable alert-<?php echo $msgType; ?>" id="div1">
    <button data-dismiss="alert" class="close" type="button">x</button>
    <p><?php echo $msg; ?></p>
  </div>
<?php } ?>

<!--Sign up start here!-->
<div class="container container1">
  <h3>Sign up</h3>

  <form class="form-horizontal" role="form" action="Signup.php" method="post" name="f" onsubmit="return validateForm()">
  <!--;"-->
   
    <div class="form-group">
      <label class="control-label col-sm-2" for="name">Name</label>
      <div class="col-sm-10">
        <input type="text" class="form-control" name="name" id="Name" placeholder="Enter name">
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Username</label>
      <div class="col-sm-10">          
        <input type="text" class="form-control" name="username"  id="username" placeholder="Enter username"> 
      </div>
    </div>

    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Email</label>
      <div class="col-sm-10">          
        <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
      </div>
    </div>

    <div class="form-group">      
    <label class="control-label col-sm-2" for="pwd">Password</label>  
      <div class="col-sm-10">          
        <input type="password" class="form-control" name="password1" id="pwd1" placeholder="Enter password">
      </div>
    </div>
        <div class="form-group">      
    <label class="control-label col-sm-2" for="pwd">Confirm Password</label>  
      <div class="col-sm-10">          
        <input type="password" class="form-control" id="pwd2"  name="password2" placeholder="Enter confirm password">
      </div>
    </div>

    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
       <button type="Submit" name="sub" class="mtbtn1 btn btn-default" id="notif">Submit</button>
        <p style="margin: 10px;"></p>
        <a href="Sign-in.php" class=" btn btn-info" style="width: 100%; font-weight: 600;">Sign in</a>
      </div>
    </div>
  </form>

</div>







<?php require("Attribute/footer.php");?>
</body> 
<!--validations-->
<script type="text/javascript">

$(document).ready(function(){
    $("#notif").click(function(){
        $("#div1").fadeOut(3000);
    });
});


  function validateForm() {

    var your_name = $.trim($("#Name").val());
    var username = $.trim($("#username").val());
    var email = $.trim($("#email").val());
    var pass1 = $.trim($("#pwd1").val());
    var pass2 = $.trim($("#pwd2").val());

  // validate name
    if (your_name == "") {
      alert("Enter your name.");
      $("#Name").focus();
      return false;
    } else if (your_name.length < 3) {
      alert("Name must be atleast 3 character.");
      $("#lname").focus();
      return false;
    }
  // validate username
    if (username == "") {
      alert("Enter your username.");
      $("#fname").focus();
      return false;
    } else if (username.length < 3) {
      alert("Name must be atleast 3 character.");
      $("#username").focus();
      return false;
    }


    // validate email
    if (!isValidEmail(your_email)) {
      alert("Enter valid email.");
      $("#email").focus();
      return false;
    }

    // validate subject
    if (pass1 == "") {
      alert("Enter password");
      $("#pwd1").focus();
      return false;
    } else if (pass1.length < 6) {
      alert("Password must be atleast 6 character.");
      $("#pwd1").focus();
      return false;
    }

    if (pass1 != pass2) {
      alert("Password does not matched.");
      $("#pwd2").focus();
      return false;
    }

    return true;
  }

  function isValidEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
  }



</script>    
</html>