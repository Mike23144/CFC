<footer class="container-fluid">
  <p>2018-CFC</p>
</footer>