<div id="header">
  <div class="logo">
    <a href="Admin-index.php">OTWAE</a>
 &nbsp; <span style="color: white;">Online tutorial with Assesment test exam</span>  </div>

 		<div class="container-A">
 		<div class="logo3">
 		

 		</div>
 		<p style="float: left; margin-right: .5em;">Admin:


  		<?php  if (isset($_SESSION['user'])) : ?>
        <p style="font-size: 18px;"><?php echo $_SESSION['user']['name']; ?></p>
       <?php endif ?></p>
       </div>

</div>
