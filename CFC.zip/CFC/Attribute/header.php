<!DOCTYPE html>
<html>
<head>
  <title>CFC - </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
  <nav class="mynav navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header" >
        <a class=" nav1 navbar-brand" href="index.php">CFC</a>
      </div>
      <ul class=" nav3 nav navbar-nav" style="float: right;">
        <li class="active"><a href="index.php">PROJECT</a></li>
        <li><a href="#">CREDENTIALS</a></li>
        <li><a href="#">ABOUT</a></li>>
        <li><a href="contact.php">CONTACT</a></li>
        <li><a href=""></a>></li>

        <ul class="nav navbar-nav navbar-right">
          <li class="btn-signin"><a href="Sign-in.php">SIGN IN</a></li>
        </ul>
      </ul>
      


    </div>
  </nav>
</body>
</html>