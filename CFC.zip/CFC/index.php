<?php 
  include('functions.php');
  if (!isLoggedIn()) {
    $_SESSION['msg'] = "You must log in first";
    header('location: Sign-in.php');
  }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Online Assessment test : Home</title>
</head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="css/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<?php include('Attribute/header.php') ?>
<body>



<div class="container">
  <h3></h3>
  <p></p>
</div>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-3 sidenav " >
     <h4 style="text-align: center; font-weight: 600 ;">Topics</h4>

      <!--English topics-->
     <h5 style="text-align: left; font-weight: 600;">English</h5>
     <a href="Lesson/L1.php" target="L1" >THE PEARL- CONFLICT A</a>
     <div>
     <a href="">THE PEARL - LESSON 1</a>
     </div>
     <div>
     <a href="">FIGURATIVE LANGUAGE - THE PEARL</a>
     </div>
         <div>
     <a href="">THE PEARL - LESSON 1</a>
     </div>
     <div>
     <a href="">FIGURATIVE LANGUAGE - THE PEARL</a>
     </div>
        <div>
     <a href="">THE PEARL - LESSON 1</a>
     </div>
     <div>
     <a href="">FIGURATIVE LANGUAGE - THE PEARL</a>
     </div>

      <!--English Science-->
     <h5 style="text-align: left; font-weight: 600;">Science</h5>
      <a href="">THE PEARL- CONFLICT A</a>
     <div>
     <a href="">THE PEARL - LESSON 1</a>
     </div>
     <div>
     <a href="">FIGURATIVE LANGUAGE - THE PEARL</a>
     </div>
        <div>
     <a href="">THE PEARL - LESSON 1</a>
     </div>
     <div>
     <a href="">FIGURATIVE LANGUAGE - THE PEARL</a>
     </div>
        <div>
     <a href="">THE PEARL - LESSON 1</a>
     </div>
     <div>
     <a href="">FIGURATIVE LANGUAGE - THE PEARL</a>
     </div>

           <!--English Math-->
      <h5 style="text-align: left; font-weight: 600;">Math</h5>
      <a href="Lesson/M1.php" target="L1">mathematics | Kindergarten</a>
     <div>
     <a href="Lesson/M2.php" target="L1">Mathematics | Grade 1</a>
     </div>
     <div>
     <a href="">mathematics | Grade 2</a>
     </div>
        <div>
     <a href="">mathematics | Grade 3</a>
     </div>
     <div>
     <a href="">mathematics | Grade 4</a>
     </div>
        <div>
     <a href="">mathematics | Grade 5</a>
     </div>
     <div>
     <a href="">mathematics | Grade 6</a>
     </div>


</div>
 <div class=" w12 panel  panel-success class">
      <div class="panel-heading">  <h4 style="text-align: right; margin-right: 5em;">Hello:</h4></div> 
        <?php  if (isset($_SESSION['user'])) : ?>
        <p style="font-size: 18px;margin-right: 1.8em; float: right;margin-top: -2.4em;"><?php echo $_SESSION['user']['name']; ?></p>
       <?php endif ?>


      <h3 style="text-align: left;font-weight: 600;margin-top: -46px;float: left; margin-left: .6em; width: 89%;" >Lesson

        
</h3> 
      <div id="_blank" class="panel-body">
   
      <iframe name="L1" height = "450" style="width: 100%;" class="iframe">
      </iframe>
   
    <a href="" class="btn btn-danger" role="button">Clear</a>
    <a href="Exam.php" class="btn btn-success" role="button" style="float: right;">Test your knowledge</a>

      </div>
      

    </div>
</div>
</div>


<footer class="container-fluid" style="text-align: center;">
  <H4>OTWAE</H4>
  <p>Online Tutorial With Assessment Exam</p>
   <p></p>
</footer>
</body>			
</html>